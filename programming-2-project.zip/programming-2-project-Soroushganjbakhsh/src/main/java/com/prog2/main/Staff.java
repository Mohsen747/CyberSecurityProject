/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.prog2.main;

/**
 *
 * @author sganj
 */
class Staff extends Person implements PayRoll {
    private String duty;
    private int weeklyWorkingHours;

    private static final int MAX_WEEKLY_WORKING_HOURS = 40;

    public Staff(String firstName, String lastName, String email, int age, String id) {
        super(firstName, lastName, email, age, id);
    }

    public String getDuty() {
        return duty;
    }

    public void setDuty(String duty) {
        this.duty = duty;
    }

    public int getWeeklyWorkingHours() {
        return weeklyWorkingHours;
    }

    public void setWeeklyWorkingHours(int weeklyWorkingHours) {
        if (weeklyWorkingHours > MAX_WEEKLY_WORKING_HOURS) {
            this.weeklyWorkingHours = MAX_WEEKLY_WORKING_HOURS;
        } else {
            this.weeklyWorkingHours = weeklyWorkingHours;
        }
    }

    @Override
    public double computePayRoll() {
        double salary = weeklyWorkingHours * 32 * 2 * 0.75;
        return salary;
    }
}
