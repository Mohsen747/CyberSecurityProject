package com.prog2.main;
/**
 * @author adinashby
 *
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main implements ActionListener {

    private JFrame frame;
    private JButton teacherButton;
    private JButton staffButton;
    private JButton departmentButton;

    public Main() {
        // Create the main window
        frame = new JFrame("University System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new GridLayout(3, 1));

        // Create the buttons
        teacherButton = new JButton("Teacher");
        teacherButton.addActionListener(this);
        staffButton = new JButton("Staff");
        staffButton.addActionListener(this);
        departmentButton = new JButton("Department");
        departmentButton.addActionListener(this);

        // Add the buttons to the main window
        frame.add(teacherButton);
        frame.add(staffButton);
        frame.add(departmentButton);

        // Set the size and make the window visible
        frame.setSize(300, 200);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new Main();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == teacherButton) {
            Teacher teacher = new Teacher("123", "John", "Doe", 30, "johndoe@email.com",
                    "Mathematics", "PhD", true);
            JOptionPane.showMessageDialog(frame, "Teacher salary: " + teacher.computePayRoll());
        } else if (e.getSource() == staffButton) {
            Staff staff = new Staff("Jane", "Doe", "janedoe@email.com", 25, "456");
            staff.setWeeklyWorkingHours(50);
            JOptionPane.showMessageDialog(frame, "Staff salary: " + staff.computePayRoll());
        } else if (e.getSource() == departmentButton) {
            Teacher dean = new Teacher("789", "Jane", "Smith", 40, "janesmith@email.com",
                    "Computer Science", "Master", true);
            Department department = new Department("IT", "Information Technology", dean);
            Teacher teacher1 = new Teacher("101", "Bob", "Jones", 35, "bobjones@email.com",
                    "Information Technology", "PhD", false);
            Teacher teacher2 = new Teacher("102", "Mary", "Johnson", 32, "maryjohnson@email.com",
                    "Computer Science", "Bachelor", true);
            department.addTeacher(teacher1);
            department.addTeacher(teacher2);
            Staff staff = new Staff("Alex", "Brown", "alexbrown@email.com", 28, "789");
            staff.setWeeklyWorkingHours(35);
            department.addStaff(staff);
            JOptionPane.showMessageDialog(frame, "Department salary: " + department.computePayRoll());
        }
    }
}
