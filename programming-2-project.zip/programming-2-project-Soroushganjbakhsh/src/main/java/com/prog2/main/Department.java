/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.prog2.main;


/**
 *
 * @author sganj
 */

import java.util.ArrayList;
import java.util.List;

public class Department implements PayRoll {
    private final String id;
    private final String name;
    private final Teacher dean;
    private final List<Teacher> teachers = new ArrayList<>();
    private final List<Staff> staff = new ArrayList<>();

    public Department(String id, String name, Teacher dean) {
        this.id = id;
        this.name = name;
        this.dean = dean;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Teacher getDean() {
        return dean;
    }

    public List<Teacher> getTeachers() {
        return teachers;
    }

    public List<Staff> getStaff() {
        return staff;
    }

    public void addTeacher(Teacher teacher) {
        teachers.add(teacher);
    }

    public void addStaff(Staff staffMember) {
        staff.add(staffMember);
    }

    public void removeTeacher(String teacherId) {
        for (int i = 0; i < teachers.size(); i++) {
            if (teachers.get(i).getId().equals(teacherId)) {
                teachers.remove(i);
                break;
            }
        }
    }

    public void removeStaff(String staffId) {
        for (int i = 0; i < staff.size(); i++) {
            if (staff.get(i).getId().equals(staffId)) {
                staff.remove(i);
                break;
            }
        }
    }

    public Teacher getTeacher(String teacherId) {
        for (Teacher t : teachers) {
            if (t.getId().equals(teacherId)) {
                return t;
            }
        }
        return null;
    }

    public Staff getStaff(String staffId) {
        for (Staff s : staff) {
            if (s.getId().equals(staffId)) {
                return s;
            }
        }
        return null;
    }

    /**
     *
     * @return
     */
    @Override
    public double computePayRoll() {
        double totalPay = dean.computePayRoll();
        for (Teacher teacher : teachers) {
            totalPay += teacher.computePayRoll();
        }
        for (Staff staffMember : staff) {
            totalPay += staffMember.computePayRoll();
        }
        return totalPay;
    }
}
