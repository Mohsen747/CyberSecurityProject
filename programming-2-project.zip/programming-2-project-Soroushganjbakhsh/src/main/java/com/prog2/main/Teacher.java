/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.prog2.main;

/**
 *
 * @author sganj
 */
class Teacher extends Person implements PayRoll {
    private final String specialty;
    private final String degree;
    private final boolean isFullTime;
    private double HoursWorked;
    
    private static final double BACHELOR_RATE = 42.0;
    private static final double MASTER_RATE = 82.0;
    private static final double PHD_RATE = 112.0;

    public Teacher(String id, String firstName, String lastName, int age, String email,
                   String specialty, String degree, boolean isFullTime) {
        super(id, firstName, lastName, age, email);
        this.specialty = specialty;
        this.degree = degree;
        this.isFullTime = isFullTime;
    }

    public String getSpecialty() {
        return specialty;
    }

    public String getDegree() {
        return degree;
    }

    public boolean isFullTime() {
        return isFullTime;
    }

    public String getCategory() {
        return "Teacher";
    }

    @Override
    public double computePayRoll() {
        double degreeRate = getDegreeRate();
        double salary;
        if (isFullTime) {
            salary = 32 * degreeRate * 2 * 0.85;
        } else {
            salary = getHoursWorked() * degreeRate * 2 * 0.76;
        }
        return salary;
    }

    public double getHoursWorked() {
        return HoursWorked;
    }

    private double getDegreeRate() {
        return switch (degree) {
            case "Bachelor" -> BACHELOR_RATE;
            case "Master" -> MASTER_RATE;
            case "PhD" -> PHD_RATE;
            default -> 0.0;
        };
    }



    public void setHoursWorked(double HoursWorked) {
        this.HoursWorked = HoursWorked;
    }
}

