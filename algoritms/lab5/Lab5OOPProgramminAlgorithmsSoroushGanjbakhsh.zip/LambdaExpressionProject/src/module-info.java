/**
 * 
 */
/**
 * @author sganj
 *
 */
module LambdaExpressionProject {
}