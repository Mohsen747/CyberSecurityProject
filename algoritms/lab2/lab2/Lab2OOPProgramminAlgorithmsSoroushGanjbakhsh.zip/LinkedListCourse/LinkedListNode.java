package LinkedListCourse;

public class LinkedListNode {

	public Course courseInfo;
	public LinkedListNode courseLink;
	
	public  LinkedListNode()
	{
		courseInfo = new Course();
	}

	public void setCourseLink(LinkedListNode newCourseNode) {
		// TODO Auto-generated method stub
		
	}

	public LinkedListNode getCourseLink() {
		// TODO Auto-generated method stub
		return null;
	}

}
