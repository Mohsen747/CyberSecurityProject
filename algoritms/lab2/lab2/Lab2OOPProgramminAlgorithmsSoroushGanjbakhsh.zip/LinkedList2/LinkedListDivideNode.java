package LinkedList2;

public class LinkedListDivideNode {
public Divide divideInfo;
public LinkedListDivideNode dividelink;
public LinkedListDivideNode divideLink;

public LinkedListDivideNode() {
divideInfo = new Divide();
}
}

