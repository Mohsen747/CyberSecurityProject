package LinkedList1;

public class LinkedListNode {
	
	public int info;
	public LinkedListNode link ;
	
	public LinkedListNode() {
		this.info = 0;
		this.link = null;
	}

}