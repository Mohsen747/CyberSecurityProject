package lambdaHashMapFacultyProject;
import java.util.*;
import java.util.stream.Collectors;

public class TestFaculty {

    public static void main(String[] args) {
        Map<Integer, Faculty> facultyMap = readFile("faculty.in");

        // Display the faculty keys using lambda expression and stream processing
        System.out.println("Faculty keys:");
        facultyMap.keySet().stream().forEach(key -> System.out.print(key + " "));
        System.out.println();

        // Sort faculty map by key and display
        System.out.println("Sorted faculty map (by key):");
        Map<Integer, Faculty> sortedByKey = new TreeMap<>(facultyMap);
        sortedByKey.forEach((key, value) -> System.out.println(key + " " + value));

        // Sort faculty map by bonus amount and display
        System.out.println("Sorted faculty map (by bonus amount):");
        Map<Integer, Faculty> sortedByBonus = facultyMap.entrySet().stream()
                .sorted(Map.Entry.comparingByValue(Comparator.comparingDouble(Faculty::doCalcBonus)))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));
        sortedByBonus.forEach((key, value) -> System.out.println(key + " " + value));
    }

    private static Map<Integer, Faculty> readFile(String filename) {
        Map<Integer, Faculty> facultyMap = new HashMap<>();

        try (Scanner scanner = new Scanner(filename)) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] fields = line.split("\t");

                int id = Integer.parseInt(fields[0]);
                String lname = fields[1];
                String fname = fields[2];
                double salary;
                double bonusRate = Double.parseDouble(fields[4]);

                if (fields[3].matches("-?\\d+(\\.\\d+)?")) {
                    salary = Double.parseDouble(fields[3]);
                } else {
                    salary = 0.0; // or some other default value
                    System.err.println("Invalid salary format for record: " + line);
                }

                facultyMap.put(id, new Faculty(id, lname, fname, salary, bonusRate));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return facultyMap;
    }
}


