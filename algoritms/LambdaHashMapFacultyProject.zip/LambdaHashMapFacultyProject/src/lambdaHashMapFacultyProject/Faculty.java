package lambdaHashMapFacultyProject;

public class Faculty {
    private int f_id;
    private String FLname;
    private String f_Fname;
    private double f_Salary;
    private double f_BounesRate;
    private final double f_tax = 0.075;
    private final double p_tax = 0.06;

    public Faculty(int f_id, String FLname, String f_Fname, double f_Salary, double f_BounesRate) {
        this.f_id = f_id;
        this.FLname = FLname;
        this.f_Fname = f_Fname;
        this.f_Salary = f_Salary;
        this.f_BounesRate = f_BounesRate;
    }

    public double doClac_Bonus() {
        return f_BounesRate * f_Salary;
    }

    public double doBounus_tax() {
        double bonus = doClac_Bonus();
        return bonus * (f_tax + p_tax);
    }

    public int getF_id() {
        return f_id;
    }

    public String getFLname() {
        return FLname;
    }

    public String getF_Fname() {
        return f_Fname;
    }

    public double getF_Salary() {
        return f_Salary;
    }

    public double getF_BounesRate() {
        return f_BounesRate;
    }

    public String toString() {
        return f_id + "\t" + FLname + "\t" + f_Fname + "\t" + f_Salary + "\t" + f_BounesRate;
    }
}
