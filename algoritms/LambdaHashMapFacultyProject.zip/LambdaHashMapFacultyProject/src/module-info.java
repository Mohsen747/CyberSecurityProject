/**
 * 
 */
/**
 * @author sganj
 *
 */
module LambdaHashMapFacultyProject {
}