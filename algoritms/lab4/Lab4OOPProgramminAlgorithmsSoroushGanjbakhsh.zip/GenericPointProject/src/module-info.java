/**
 * 
 */
/**
 * @author sganj
 *
 */
module GenericPointProject {
}