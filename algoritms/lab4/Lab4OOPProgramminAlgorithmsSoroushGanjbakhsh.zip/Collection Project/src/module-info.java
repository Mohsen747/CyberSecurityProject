/**
 * 
 */
/**
 * @author sganj
 *
 */
module CollectionProject {
}