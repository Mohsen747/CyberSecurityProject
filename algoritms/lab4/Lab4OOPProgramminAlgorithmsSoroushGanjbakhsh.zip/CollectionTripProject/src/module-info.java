/**
 * 
 */
/**
 * @author sganj
 *
 */
module CollectionTripProject {
}