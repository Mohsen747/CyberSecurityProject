/**
 * 
 */
/**
 * @author sganj
 *
 */
module CollectionExamplesProject {
}