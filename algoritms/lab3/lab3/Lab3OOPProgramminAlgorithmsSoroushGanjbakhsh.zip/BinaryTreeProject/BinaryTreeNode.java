package BinaryTree;

public class BinaryTreeNode {
    int info;
    BinaryTreeNode leftChild;
    BinaryTreeNode rightChild;

    public BinaryTreeNode(int info) {
        this.info = info;
        leftChild = null;
        rightChild = null;
    }
}

