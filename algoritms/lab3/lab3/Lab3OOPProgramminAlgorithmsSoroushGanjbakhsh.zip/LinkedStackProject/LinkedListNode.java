package LinkedStack;

public class LinkedListNode {
	
	int info;
	LinkedListNode link;

	public LinkedListNode() {
		info = 0;
		link = null;
	}
}



