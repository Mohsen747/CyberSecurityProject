/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.prog2.main;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.ListModel;

/**
 *
 * @author macbookpro2016
 */
public class FileInOut {

    public static ArrayList<Department> deps = new ArrayList<>();
    public static ArrayList<Teacher> allTeachers = new ArrayList<>();
    public static ArrayList<Staff> allStaff = new ArrayList<>();
    public static String pathInput = "./department_Info.txt";
    public static String pathOutput = "./department_Info_Output.txt";

    public static void main(String[] args) {

        readData(pathInput);
        System.out.println("teachers=========>" + allTeachers);
    

    }

    public static void readData(String path) {

        File file = new File(path);

        try (Scanner input = new Scanner(file)) {		// try with resource
            while (input.hasNext()) {

                String[] eachLine = input.nextLine().split(",");

                Teacher teacher = new Teacher(eachLine[0], eachLine[1], eachLine[2], eachLine[3], eachLine[4], Integer.parseInt(eachLine[5]),
                        eachLine[6].toString().charAt(0), eachLine[7], eachLine[8], eachLine[9], Boolean.parseBoolean(eachLine[10]),
                        Boolean.parseBoolean(eachLine[11]), Double.parseDouble(eachLine[12]));

                allTeachers.add(teacher);

            }

        } catch (IOException e) {
            System.out.print("File not found");
        }
// once the try-catch structure is over, the input resource will be released

    }

    public static void writeData(ListModel<String> emp, String path) {

//        try (FileWriter fw = new FileWriter(path, true)) {
//            fw.write("hi teachers\n");
//  fw.write(teacher.getSIN() + " , " + teacher.getDepartmentID() + " , " + teacher.getFirst_Name() + " , " + teacher.getLast_Name() + " , " + teacher.getEmail() + " , " + teacher.getAge() + " , " + teacher.getGender() + " , " + teacher.getPhone_Number() + " , " + teacher.getSpecialty() + " , " + teacher.getDegree() + " , " + teacher.isIsFullTime() + " , " + teacher.isDean() + " , " + teacher.getHoursWorked() + ".\n");
//        } catch (IOException e) {
//            System.out.println("Fail to write to the file");
//        }

int val = emp.getSize(); //get the size of employeeList and store in a variable
//        PrintWriter writer = null;
       
        try {
           FileWriter fw = new FileWriter(path, true);
           fw.write(val);//write size of employeeList to textFile first which help us to store numberof entries to file  useing loop          
           for(int i = 0  ; i < val ; i++){
               fw.write(emp.getElementAt(i));//get the element from emploee list modle via indexvalue
  
            }
       } catch (Exception e) {
            System.err.println("Error Saving to file");
        }
    }

}
