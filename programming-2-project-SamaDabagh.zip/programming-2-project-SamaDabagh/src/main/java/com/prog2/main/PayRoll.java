/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.prog2.main;

/**
 *
 * @author macbookpro2016
 */
public interface PayRoll {
    public double computePayRoll();
    
}
