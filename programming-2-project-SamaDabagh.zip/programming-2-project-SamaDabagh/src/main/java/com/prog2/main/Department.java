 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.prog2.main;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

/**
 *
 * @author macbookpro2016
 */
public class Department {

    private String department_Name;
    String departmentID;
    private Teacher dean;
    private List<Teacher> teachers = new ArrayList<>();
    private List<Staff> staff = new ArrayList<>();
    
    

    public Department(String department_Name, String departmentID, List<Teacher> teachers, List<Staff> staff,Teacher dean) {
        this.department_Name = department_Name;
        this.departmentID = departmentID;
        this.staff = staff;
        this.teachers = teachers;
        this.dean = dean;
    }

    public Department(String department_Name, String departmentID) {
        this.department_Name = department_Name;
        this.departmentID = departmentID;
    }

    public String getDepartment_Name() {
        return department_Name;
    }

    public void setDepartment_Name(String department_Name) {
        this.department_Name = department_Name;
    }

    public String getDepartmentID() {
        return departmentID;
    }

    public void setDepartmentID(String departmentID) {
        this.departmentID = departmentID;
    }

    public Teacher getDean() {
        for (int i = 0; i < getTeachers().size(); i++) {
            if (getTeachers().get(i).isDean()) {
                dean = (this.getTeachers().get(i));
            }
        }
        return dean;
    }

    public void setDean(Teacher dean) {
        for (int i = 0; i < getTeachers().size(); i++) {
            if (getTeachers().get(i).isDean()) {
                this.dean = (this.getTeachers().get(i));
            }
        }

    }

    public List<Teacher> getTeachers() {
        return teachers;
    }

    public void setTeachers(List<Teacher> teachers) {
        this.teachers = teachers;
    }

    public List<Staff> getStaff() {
        return staff;
    }

    public void setStaff(List<Staff> staff) {

        this.staff = staff;
    }

    public Teacher dean(List<Teacher> teachers) {

        return dean;
    }

    public boolean doseTeacherExist(List<Teacher> teachers) {
        return (teachers.isEmpty() ? false : true);
    }

    public boolean doseStaffExist(List<Staff> staff) {
        return (staff.isEmpty() ? false : true);
    }

    public boolean hasDean(String SIN) throws NoDeanException {
        for (int i = 0; i < getTeachers().size(); i++) {
            if (getTeachers().get(i).isDean()) {
                return true;
            }

        }
        throw new NoDeanException("There is no dean in the list of teachers.");
    }

    public void addTeacher(Teacher teacher) {
        teachers.add(teacher);
    }

    public void removeTeacher(String teacherId) {
        for (Teacher teacher : teachers) {
            if (teacher.getSIN().equals(teacherId)) {
                teachers.remove(teacher);
            }
        }
    }

    public void addStaff(Staff staff) {
        this.staff.add(staff);
    }

    public void removeStaff(String staffId) {
        for (int i = 0; i < staff.size(); i++) {
            if (staff.get(i).getSIN().equals(staffId)) {
                staff.remove(i);
                break;
            }
        }
    }

    @Override
    public String toString() {
        return "Department{" + "department_Name=" +department_Name+ ", departmentID=" + departmentID + ", dean=" + dean + ", teachers=" + teachers + ", staff=" + staff + '}';
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 53 * hash + Objects.hashCode(this.department_Name);
        hash = 53 * hash + Objects.hashCode(this.departmentID);
        hash = 53 * hash + Objects.hashCode(this.dean);
        hash = 53 * hash + Objects.hashCode(this.teachers);
        hash = 53 * hash + Objects.hashCode(this.staff);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Department other = (Department) obj;
        if (!Objects.equals(this.department_Name, other.department_Name)) {
            return false;
        }
        if (!Objects.equals(this.departmentID, other.departmentID)) {
            return false;
        }
        if (!Objects.equals(this.dean, other.dean)) {
            return false;
        }
        if (!Objects.equals(this.teachers, other.teachers)) {
            return false;
        }
        return Objects.equals(this.staff, other.staff);
    }

}
