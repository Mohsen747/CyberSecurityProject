package com.prog2.main;

import java.time.LocalDate;
import java.time.Month;

/**
 * @author adinashby
 *
 */

public class Main {

	/**
	 * Write your test code below in the main.
	 *
	 */
	public static void main(String[] args) {
//	 Teacher teacher = new Teacher("chimistry", "PHD", true, "1234", "Samaneh", "Dabbaghchi","s.dabbaghchi@gmail.com", LocalDate.of(1979, 11, 02), 'F');
//       System.out.println(teacher.getDOB().toString());
//         Teacher teacher = new Teacher( "1234", "Samaneh", "Dabbaghchi");
//       System.out.println(teacher.getDOB().toString());
//         Staff staff = new Staff("2345", "John", "Smith");
         
//         System.out.println(staff.getLast_Name());
         Department department = new Department("Architecture", "01");
            System.out.println(department.toString());
	}


}