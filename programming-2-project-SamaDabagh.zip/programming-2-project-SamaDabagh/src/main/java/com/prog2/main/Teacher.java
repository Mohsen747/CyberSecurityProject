/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.prog2.main;

import java.io.Serializable;
import java.util.Objects;

/**
 *
 * @author macbookpro2016
 */
public class Teacher extends Person implements PayRoll,Serializable{
    
    private String specialty;
    private String degree;
    private boolean isFullTime;
    private boolean isDean;//parent has it
    private double hoursWorked;
    
    
    public static final double BACHELOR_RATE = 42.0;
    public static final double MASTER_RATE = 82.0;
    public static final double PHD_RATE = 112.0;


    public Teacher( 
            String SIN, 
            String departmentID,
            String first_Name,
            String last_Name,
            String email,
            int age,
            char gender, 
            String phone_Number,
            String specialty,
            String degree,
            boolean isFullTime,
            boolean isDean,
            double hoursWorked
    ) {
        super(SIN, departmentID, first_Name, last_Name, email, age, gender, phone_Number);
        this.specialty = specialty;
        this.degree = degree;
        this.isFullTime = isFullTime;
        this.isDean = isDean;
        this.hoursWorked = hoursWorked;
    }

    


    public String getSpecialty() {
        return specialty;
    }

    public void setSpecialty(String specialty) {
        this.specialty = specialty;
    }

    public String getDegree() {
        return degree;
    }

    public void setDegree(String degree) {
        this.degree = degree;
    }

    public boolean isIsFullTime() {
        return isFullTime;
    }

    public void setIsFullTime(boolean isFullTime) {
        this.isFullTime = isFullTime;
    }


    public boolean isIsDean() {
        return isDean;
    }

    public void setIsDean(boolean isDean) {
        this.isDean = isDean;
    }

    public double getHoursWorked() {
        return hoursWorked;
    }

    public void setHoursWorked(double HoursWorked) {
        this.hoursWorked = hoursWorked;
    }
    
    private double getDegreeRate() {
            String degree = this.getDegree();

        switch (degree) {
            case "Bachelor" : return BACHELOR_RATE;
            case "Master" : return MASTER_RATE;
            case "PhD" : return PHD_RATE;
            default : return 0.0;
        }
    }


    @Override
    public boolean isDean() {
        return isDean;
    }

    @Override
    public double computePayRoll() {
        double degreeRate = this.getDegreeRate();
        double salary;
        
        if (isFullTime) {
            salary = 32 * degreeRate * 2 * 0.85;
        } else {
            salary = getHoursWorked() * degreeRate * 2 * 0.76;
        }
        return Math.round(salary); 
    }

    @Override           
    public String toString() {
       
        return  "Teacher{ SIN=" + super.getSIN() +", departmentID= "+ super.getDepartmentID() + ", first_Name=" + super.getFirst_Name() + ", last_Name=" + super.getLast_Name() + ", email=" + super.getEmail() + ", age=" + super.getAge() + ", gender=" + super.getGender() + ", phone_Number=" + super.getPhone_Number()+ ", specialty=" + specialty + ", degree=" + degree + ", isFullTime=" + isFullTime + ", isDean=" + isDean + ", HoursWorked=" + hoursWorked + ", salary==" + this.computePayRoll() +'}';
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 83 * hash + Objects.hashCode(this.specialty);
        hash = 83 * hash + Objects.hashCode(this.degree);
        hash = 83 * hash + (this.isFullTime ? 1 : 0);
        hash = 83 * hash + (this.isDean ? 1 : 0);
        hash = 83 * hash + (int) (Double.doubleToLongBits(this.hoursWorked) ^ (Double.doubleToLongBits(this.hoursWorked) >>> 32));
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Teacher other = (Teacher) obj;
        if (this.isFullTime != other.isFullTime) {
            return false;
        }
        if (this.isDean != other.isDean) {
            return false;
        }
        if (Double.doubleToLongBits(this.hoursWorked) != Double.doubleToLongBits(other.hoursWorked)) {
            return false;
        }
        if (!Objects.equals(this.specialty, other.specialty)) {
            return false;
        }
        return Objects.equals(this.degree, other.degree);
    }



  
    
    
}
