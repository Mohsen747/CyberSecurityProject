/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.prog2.main;

import java.io.Serializable;
import java.util.Objects;

/**
 *
 * @author macbookpro2016
 */
public class Staff extends Person implements PayRoll, Serializable{
    
    private String duty;
    private int workLoad;

    private static final int MAX_WEEKLY_WORKING_HOURS = 40;

    public Staff(String duty, int workLoad, String SIN, String departmentID, String first_Name, String last_Name, String email, int age, char gender, String phone_Number) {
        super(departmentID, SIN, first_Name, last_Name, email, age, gender, phone_Number);
        this.duty = duty;
        this.workLoad = workLoad;
    }



    

    public String getDuty() {
        return duty;
    }

    public void setDuty(String duty) {
        this.duty = duty;
    }

    public int getWorkLoad() {
        return workLoad;
    }

    public void setWorkLoad(int workLoad) {
         if (workLoad > MAX_WEEKLY_WORKING_HOURS) {
            this.workLoad = MAX_WEEKLY_WORKING_HOURS;
        } else {
            this.workLoad = workLoad;
        }
    }


    @Override// implement Interface
    public double computePayRoll() {
        double salary = workLoad * 32 * 2 * 0.75;
        return salary;  
    }

    @Override   //  extends abstract  method
    public boolean isDean() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String toString() {
        return "Staff{ SIN=" + super.getSIN() + " departmentID =" + super.getDepartmentID() + ", first_Name=" + super.getFirst_Name() + ", last_Name=" + super.getLast_Name() + ", email=" + super.getEmail() + ", age=" + super.getAge() + ", gender=" + super.getGender() + ", phone_Number=" + super.getPhone_Number()+ "duty=" + duty + ", workLoad=" + workLoad + '}';
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 13 * hash + Objects.hashCode(this.duty);
        hash = 13 * hash + this.workLoad;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Staff other = (Staff) obj;
        if (this.workLoad != other.workLoad) {
            return false;
        }
        return Objects.equals(this.duty, other.duty);
    }

 
    
    
}
