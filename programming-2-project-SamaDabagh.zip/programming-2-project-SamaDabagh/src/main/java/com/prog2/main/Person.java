/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.prog2.main;

import java.io.Serializable;
import java.util.Objects;

/**
 *
 * @author macbookpro2016
 */
public abstract class Person implements Serializable {

    private String SIN;
    private String departmentID;
    private String first_Name;
    private String last_Name;
    private String email;
    private int age;
    private char gender;
    private String phone_Number;

    public Person(  String SIN,String departmentID, String first_Name, String last_Name, String email, int age, char gender, String phone_Number) {
        this.SIN = SIN;
        this.departmentID = departmentID;
        this.first_Name = first_Name;
        this.last_Name = last_Name;
        this.email = email;
        this.age = age;
        this.gender = gender;
        this.phone_Number = phone_Number;
    }
    

    // Constructor with all parameters   


    //Abstract method
    public abstract boolean isDean();

    public String getSIN() {
        return SIN;
    }

    public void setSIN(String SIN) {
        this.SIN = SIN;
    }

    public String getFirst_Name() {
        return first_Name;
    }

    public void setFirst_Name(String first_Name) {
        this.first_Name = first_Name;
    }

    public String getLast_Name() {
        return last_Name;
    }

    public void setLast_Name(String last_Name) {
        this.last_Name = last_Name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public char getGender() {
        return gender;
    }

    public void setGender(char gender) {
        this.gender = gender;
    }

    public String getPhone_Number() {
        return phone_Number;
    }

    public void setPhone_Number(String phone_Number) {
        this.phone_Number = phone_Number;
    }

    public String getDepartmentID() {
        return departmentID;
    }

    public void setDepartmentID(String departmentID) {
        this.departmentID = departmentID;
    }

// Returns string representation of Person object
    @Override
    public String toString() {
        return "Person{ SIN=" + SIN + ", departmentID=" +departmentID + "first_Name=" + first_Name + ", last_Name=" + last_Name + ", email=" + email + ", age=" + age + ", gender=" + gender + ", phone_Number=" + phone_Number + '}';
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 79 * hash + Objects.hashCode(this.SIN);
        hash = 79 * hash + Objects.hashCode(this.departmentID);
        hash = 79 * hash + Objects.hashCode(this.first_Name);
        hash = 79 * hash + Objects.hashCode(this.last_Name);
        hash = 79 * hash + Objects.hashCode(this.email);
        hash = 79 * hash + this.age;
        hash = 79 * hash + this.gender;
        hash = 79 * hash + Objects.hashCode(this.phone_Number);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Person other = (Person) obj;
        if (this.age != other.age) {
            return false;
        }
        if (this.gender != other.gender) {
            return false;
        }
        if (!Objects.equals(this.SIN, other.SIN)) {
            return false;
        }
        if (!Objects.equals(this.departmentID, other.departmentID)) {
            return false;
        }
        if (!Objects.equals(this.first_Name, other.first_Name)) {
            return false;
        }
        if (!Objects.equals(this.last_Name, other.last_Name)) {
            return false;
        }
        if (!Objects.equals(this.email, other.email)) {
            return false;
        }
        return Objects.equals(this.phone_Number, other.phone_Number);
    }



  



    

}
