/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.prog2.main;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ListModel;

/**
 *
 * @author macbookpro2016
 */
 @SuppressWarnings("unchecked")
public class FileIO {

  
//    public static String path = "teachers_Info.dat";
//
//     public static void SaveEmployeeInfo(ListModel<String> emp , String path){
//        int val = emp.getSize(); //get the size of employeeList and store in a variable
//        PrintWriter writer = null;
//       
//        try {
//           writer = new PrintWriter(path);
//           writer.println(val);//write size of employeeList to textFile first which help us to store numberof entries to file  useing loop          
//           for(int i = 0  ; i < val ; i++){
//               writer.println(emp.getElementAt(i));//get the element from emploee list modle via indexvalue
//  
//            }
//       } catch (Exception e) {
//            System.err.println("Error Saving to file");
//        }finally{
//            writer.close();
//      }
//     }
//     public static void SaveTeacher(List<Teacher> teachers){
//
//         System.out.println("Save=======>"+ teachers);
//         SerializeData(teachers);
//         
//    }
//    
//    
//    public static void SerializeData(List<Teacher> teachers) {
//
//        try {
//             
//            FileOutputStream fos = new FileOutputStream(path);
//            ObjectOutputStream oos = new ObjectOutputStream(fos);
//            for( Teacher t : teachers){
//                oos.writeObject(teachers);
//                System.out.println("Save completed");
//
//            }
//            
//             try {
//            ObjectInputStream input =  new ObjectInputStream(new FileInputStream(path));
//           Teacher teacher1 = (Teacher) input.readObject();
//                 System.out.println("teacher1========>"+ teacher1);
//            input.close();
//
//        } catch (Exception e) {
//            System.err.println("Error Opening to file");
//        } 
//            
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//
//    public static Object deserializeData() throws ClassNotFoundException, FileNotFoundException, IOException {
//
//        List<Teacher> teachers = null;
//        try (FileInputStream fis = new FileInputStream(path)) {
//            ObjectInputStream ois = new ObjectInputStream(fis);
//            teachers = (List<Teacher>) ois.readObject();
//            System.out.println("com.prog2.main.FileIO.deserializeData()");
//            return teachers;
////        } catch (IOException e) {
////            Department depArc = new Department("Architecture", "1");
////            Department depCS = new Department("Computer Sience", "2");
////            Department depBA = new Department("Buissinus Adminestration ", "3");
////            
////           teachers.add(depArc);
////            deps.add(depBA);
////            deps.add(depCS);
////            
////            return deps;
//        } catch (ClassNotFoundException ex){
//            Logger.getLogger(FileIO.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        return null;
//    }
//   

}
