/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author sganj
 */

import com.prog2.main.Staff;
import static org.junit.jupiter.api.Assertions.assertEquals;


public class StaffTest {

    
    public void testComputePayRoll() {
        Staff staff = new Staff("Clerk", 35, "123456789", "DEPT001", "John", "Doe", "john.doe@example.com", 25, 'M', "123-456-7890");
        double expectedSalary = 35 * 32 * 2 * 0.75;
        assertEquals(expectedSalary, staff.computePayRoll(), 0.01);
    }

}
