import com.prog2.main.Teacher;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class TeacherTest {
    
    @Test
    public void testComputePayRoll() {
        Teacher teacher1 = new Teacher(
            "123456789", "CS", "John", "Doe", "johndoe@example.com",
            30, 'M', "123-456-7890", "Computer Science", "Bachelor",
            true, false, 0.0
        );
        double expectedSalary = Math.round(32 * Teacher.BACHELOR_RATE * 2 * 0.85);
        Assertions.assertEquals(expectedSalary, teacher1.computePayRoll());
        
        Teacher teacher2 = new Teacher(
            "987654321", "Math", "Jane", "Doe", "janedoe@example.com",
            35, 'F', "987-654-3210", "Mathematics", "PhD",
            false, false, 20.0
        );
        expectedSalary = Math.round(20 * Teacher.PHD_RATE * 2 * 0.76);
        Assertions.assertEquals(expectedSalary, teacher2.computePayRoll());
    }
}
